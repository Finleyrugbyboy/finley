Thanks for using my mod menu (Razor Client V2.0.1) this will be an amazing choice to use this, unzip it then put the .dll file in your plugins folder and you will be good to go. Press [Y] on your controller to open the menu. [THIS MENU IS NOT A RAT I PROMISE YOU!]


				   This Was Made By TummaVR DONT STEAL MY WORK OR I WILL STEAL YOU! 

						    Copyright 2024 TummaVR Mods